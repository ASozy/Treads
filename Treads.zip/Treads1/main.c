#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

void* ThreadFunction(void* arg)
{
	printf("thread\n");
	return NULL;
}

int main()
{
	pthread_t thread;  // дескриптор потока
	printf("main\n");

	pthread_create(&thread, NULL, ThreadFunction, NULL); // создаем поток
	pthread_join(thread, NULL); // ждем завершения потока
	return 0;
}