#include <windows.h>
#include <stdio.h>

int main() {
    STARTUPINFO si;
    PROCESS_INFORMATION pi;

    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    ZeroMemory(&pi, sizeof(pi));

    // Имя исполняемого файла для запуска
    char cmd[] = "notepad.exe";

    // Создание дочернего процесса
    if (!CreateProcess(
        NULL,   // Имя модуля (NULL говорит использовать командную строку)
        cmd,    // Командная строка
        NULL,   // Защита процесса
        NULL,   // Защита потока
        FALSE,  // Наследование дескрипторов
        0,      // Флаги создания
        NULL,   // Переменные среды родителя
        NULL,   // Текущая рабочая директория
        &si,    // Указатель на STARTUPINFO
        &pi     // Указатель на PROCESS_INFORMATION
    )) {
        printf("CreateProcess failed (%d).\n", GetLastError());
        return 1;
    }

    // Ожидание завершения дочернего процесса
    WaitForSingleObject(pi.hProcess, INFINITE);

    // Закрытие дескрипторов процесса и потока
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);

    return 0;
}