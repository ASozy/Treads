#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

int number;

//--------------------------------------------------------------------
void* ThreadFunction(void* arg)
{
	while( number != 0 )
	{
		printf("Tread: %d\n", number);
		sleep(1);
	}
	return NULL;
}

//----------------------------------------------------------------------
int main()
{
	pthread_t thread;  // дескриптор потока
    number = 1;
	printf("main: print number (0 to stop)\n");

	if(pthread_create(&thread, NULL, ThreadFunction, NULL)) // создаем поток
	{   // ошибка
		printf("pthread_create fail\n");
		return(1);
	}

	while( number != 0 )
		scanf("%d", &number); // ждем ввода числа

	pthread_join(thread, NULL); // ждем завершения потока
	return 0;
}